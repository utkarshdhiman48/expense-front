export const HOLD_DELAY = 500;
