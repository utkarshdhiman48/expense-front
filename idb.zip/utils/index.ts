import getColorFromString from './getColorFromString';
import getCurrencyColor from './getCurrencyColor';

// export const getColorFromString = getColorFromString_;

export { getColorFromString, getCurrencyColor };
