export interface Person {
  id: string;
  firstName: string;
  lastName: string;
  username: string;
  accounts: string[];
}
