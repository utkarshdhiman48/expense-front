export interface Account {
  id: string;
  label: string;
  balance: number;
}
