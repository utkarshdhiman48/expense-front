export interface Category {
  id: string;
  label: string;
}
