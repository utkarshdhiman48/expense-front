export interface Distribution {
  id: string;
  amount: number;
  transaction: string;
  to: string;
  from: string;
}
